package com.ics499.clothingstore.model;

public interface Payment {
	public String doSomeEncrypting();
}
